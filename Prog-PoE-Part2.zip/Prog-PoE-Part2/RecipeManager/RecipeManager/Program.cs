﻿using System;
using System.Collections.Generic;

namespace RecipeManagementSystem
{
    // Class representing an Ingredient
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    // Class representing a Step
    public class Step
    {
        public string Description { get; set; }
    }

    // Class representing a Recipe
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        // Constructor
        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        // Method to calculate total calories of the recipe
        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories * ingredient.Quantity;
            }
            return totalCalories;
        }

        // Method to scale the recipe
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        // Method to reset ingredient quantities to original values
        public void ResetQuantities()
        {
            // Implement logic to reset quantities to original values
        }
    }

    // Class to manage multiple recipes
    public class RecipeManager
    {
        public List<Recipe> Recipes { get; set; }

        // Delegate for calorie notification
        public delegate void CalorieNotification(string recipeName);

        // Event for calorie notification
        public event CalorieNotification OnCalorieExceeded;

        // Constructor
        public RecipeManager()
        {
            Recipes = new List<Recipe>();
        }

        // Method to add a recipe
        public void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
        }

        // Method to display all recipes
        public void DisplayAllRecipes()
        {
            Recipes.Sort((x, y) => string.Compare(x.Name, y.Name)); // Sort recipes by name
            foreach (var recipe in Recipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        // Method to display details of a selected recipe
        public void DisplayRecipeDetails(string recipeName)
        {
            var recipe = Recipes.Find(r => r.Name.Equals(recipeName));
            if (recipe != null)
            {
                Console.WriteLine($"Recipe: {recipe.Name}");
                Console.WriteLine("Ingredients:");
                foreach (var ingredient in recipe.Ingredients)
                {
                    Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} {ingredient.Name} ({ingredient.Calories} calories)");
                }
                Console.WriteLine("Steps:");
                for (int i = 0; i < recipe.Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {recipe.Steps[i].Description}");
                }

                // Check if total calories exceed 300 and notify user
                if (recipe.CalculateTotalCalories() > 300)
                {
                    OnCalorieExceeded?.Invoke(recipe.Name);
                }
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Create Recipe Manager
            RecipeManager recipeManager = new RecipeManager();

            // Subscribe to Calorie Exceeded event
            recipeManager.OnCalorieExceeded += NotifyCalorieExceeded;

            // Add recipes
            AddRecipes(recipeManager);

            // Display all recipes
            Console.WriteLine("All Recipes:");
            recipeManager.DisplayAllRecipes();

            // Choose recipe to display details
            Console.WriteLine("\nEnter the name of the recipe to display details:");
            string recipeName = Console.ReadLine();
            recipeManager.DisplayRecipeDetails(recipeName);
        }

        // Method to add recipes
        static void AddRecipes(RecipeManager recipeManager)
        {
            bool addMore = true;
            while (addMore)
            {
                Recipe recipe = new Recipe();

                Console.WriteLine("\nEnter recipe name:");
                recipe.Name = Console.ReadLine();

                Console.WriteLine("\nEnter the number of ingredients:");
                int ingredientCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < ingredientCount; i++)
                {
                    Ingredient ingredient = new Ingredient();

                    Console.WriteLine("\nEnter ingredient name:");
                    ingredient.Name = Console.ReadLine();

                    Console.WriteLine("Enter quantity:");
                    ingredient.Quantity = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter unit:");
                    ingredient.Unit = Console.ReadLine();

                    Console.WriteLine("Enter calories:");
                    ingredient.Calories = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter food group:");
                    ingredient.FoodGroup = Console.ReadLine();

                    recipe.Ingredients.Add(ingredient);
                }

                Console.WriteLine("\nEnter the number of steps:");
                int stepCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < stepCount; i++)
                {
                    Step step = new Step();

                    Console.WriteLine($"\nEnter step {i + 1} description:");
                    step.Description = Console.ReadLine();

                    recipe.Steps.Add(step);
                }

                recipeManager.AddRecipe(recipe);

                Console.WriteLine("\nDo you want to add another recipe? (Y/N)");
                string addMoreChoice = Console.ReadLine().ToUpper();
                if (addMoreChoice != "Y")
                {
                    addMore = false;
                }
            }
        }

        // Method to notify user when calorie limit is exceeded
        static void NotifyCalorieExceeded(string recipeName)
        {
            Console.WriteLine($"Warning: Total calories for recipe '{recipeName}' exceed 300.");
        }
    }
}


